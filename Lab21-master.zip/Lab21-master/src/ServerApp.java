public class ServerApp {
    public static void main(String[] args) {
        new MyServer();
    }
}